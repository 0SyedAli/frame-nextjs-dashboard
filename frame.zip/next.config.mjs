/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["appsdemo.pro"], 
      },
};

export default nextConfig;
