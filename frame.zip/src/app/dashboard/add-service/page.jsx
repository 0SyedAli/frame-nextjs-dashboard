import Image from 'next/image';
import React from 'react'
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { PiPencilSimpleLineBold } from 'react-icons/pi';
const AddService = () => {
  return (
    <div className='add_service2_dash'>
      <form>
        <h4>Service #1</h4>
        <div className="row align-items-end">
          <div className="col-5">
            <div className="auth_upload_hair_cover">
              <input type="file" name="" id="" />
              <label htmlFor="">
                <div className="auhc_img_container">
                  <img className='d-none' src="" alt="" />
                  <span className="aic_icon">
                    <Image
                      src="/images/upload-icon.png"
                      width={16}
                      height={18}
                      className="pb-icon"
                      alt="Frame"
                    />
                  </span>
                  <h5>Upload header image for Hair services</h5>
                  <h5>800px  x  400px</h5>
                </div>
              </label>
            </div>
          </div>
          <div className="col-7">
            <h5 className='usi_heading'>Upload service images</h5>
            <div className="row">
              <div className="col-4">
                <div className="auth_upload_bussiness_logo">
                  <input type="file" name="" id="" />
                  <label htmlFor="">
                    <div className="aubl_img_container">
                      <img src="" alt="" />
                      <span className="aic_icon">
                        <Image
                          src="/images/upload-icon.png"
                          width={16}
                          height={18}
                          className="pb-icon"
                          alt="Frame"
                        />
                      </span>
                    </div>
                  </label>
                </div>
              </div>
              <div className="col-4">
                <div className="auth_upload_bussiness_logo">
                  <input type="file" name="" id="" />
                  <label htmlFor="">
                    <div className="aubl_img_container">
                      <img src="" alt="" />
                      <span className="aic_icon">
                        <Image
                          src="/images/upload-icon.png"
                          width={16}
                          height={18}
                          className="pb-icon"
                          alt="Frame"
                        />
                      </span>
                    </div>
                  </label>
                </div>
              </div>
              <div className="col-4">
                <div className="auth_upload_bussiness_logo">
                  <input type="file" name="" id="" />
                  <label htmlFor="">
                    <div className="aubl_img_container">
                      <img src="" alt="" />
                      <span className="aic_icon">
                        <Image
                          src="/images/upload-icon.png"
                          width={16}
                          height={18}
                          className="pb-icon"
                          alt="Frame"
                        />
                      </span>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row as_form gy-5">
          <div className="col-12">
            <input type="text" placeholder="Username" />
          </div>
          <div className="col-12">
            <select>
              <option value="">Select City</option>
              <option>abc</option>
            </select>
          </div>
          <div className="col-12">
            <select>
              <option value="">Select City</option>
              <option>abc</option>
            </select>
          </div>
          <div className="col-12">
            <textarea rows="10">Description</textarea>
          </div>
          <div className="col-12">
            <div className="dollar_input">
              <span>$</span>
              <input type="text" placeholder="" />
            </div>
          </div>
          <div className='col-12 pt-4'>
            <button className="btn theme-btn2">Continue</button>
          </div>
        </div>
      </form>
    </div>
  )
}

export default AddService