import React from 'react'

const Language = () => {
  return (
    <div>Language</div>
  )
}

export default Language