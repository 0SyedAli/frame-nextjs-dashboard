import SplashScreens from "@/components/SplashScreens";

export default function Home() {
  return (
    <>
    <SplashScreens />
    </>
  );
}
