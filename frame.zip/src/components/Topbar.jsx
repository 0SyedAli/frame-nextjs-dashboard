export default function Topbar() {
  return (
    <div className="dash_top_header">
      <div className="dth_content">
        <h4>Palatino Linotype</h4>
        <h2>Dashboard</h2>
      </div>
    </div>
  );
}