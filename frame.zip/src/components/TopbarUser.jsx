import React from 'react'

const TopbarUser = () => {
  return (
    <div>TopbarUser</div>
  )
}

export default TopbarUser